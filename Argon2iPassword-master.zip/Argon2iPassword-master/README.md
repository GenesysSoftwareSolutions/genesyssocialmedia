# Argon2iPassword
Argon2i password encryption for OSSN v5.1 or >  You can change default password encryption method to Argon2i by using this component.  It replace the bcrypt the default password encryption introduced in OSSN v5.1.
