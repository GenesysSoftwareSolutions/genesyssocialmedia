# Greetings
Greet users based on morning, day, evening, night
