ProfAccess
==========

Profile access components allows you to disable profile access for non loggedin users
