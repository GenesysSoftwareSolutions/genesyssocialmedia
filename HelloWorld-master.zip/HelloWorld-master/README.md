HelloWorld
==========

Hello world component allows new developers to learn few things for ossn quickly.

V1.0
* Tells you how you can add your css code in deafult ossn css file.
* Tells you how you can add your js code in deafult ossn js file.
* Tell you how you create seperate css file and how to add its link in header of ossn.

NOTE: If you have downloaded from github then you need to re zip with correct directory name.

The zip name must be HelloWorld and after extracting it must have HelloWorld/ossn_com.php