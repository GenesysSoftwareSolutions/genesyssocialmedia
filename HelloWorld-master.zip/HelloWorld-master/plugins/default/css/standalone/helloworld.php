.hello-world-standalone {
  //css goes here
}