# GifSupport
Allow users to upload animated gif to the website.

Thanks to ZetMan for implementation of animated gif to the system.  <https://www.opensource-socialnetwork.org/u/zetman>